import io from 'socket.io-client';
import { chatState } from '../utils/chatProvider';
import axios from 'axios';
import { Input } from '@chakra-ui/input';
import './styles.css';
import { IconButton, Spinner, useToast } from "@chakra-ui/react";
import { ArrowBackIcon } from "@chakra-ui/icons";
import { useEffect, useState } from 'react';
import { config } from 'dotenv';

const ENDPOINT = 'http://localhost:5050';
var socket, selectedChatRoomCompare;

const singleChatRoom = ( { fetchAgain, setFetchAgain } ) => {
    const [messages, setMessages] = useState([]);
    const [newMessage, setNewMessage] = useState("");
    const toast = useToast();
}
const { selectedChatRoom, setSelectedChatRoom, user } = chatState();


const sendMessage = async (event) => {
    if (event.key === "Enter" && newMessage) {
        try {
            setNewMessage("");
            const { data } = await axios.post( '/api/message',
                {
                    content: newMessage,
                },
                config
            );
            socket.emit('new message', data);
            setMessages( [...messages, data] );
        } catch (err) {
            toast( {
                title: 'error',
                description: 'message failed to send',
                status: 'err',
                duration: 5000,
                isClosable: true,
                position: bottom,
            });
        }
    }
};

useEffect( () => {
    socket = io(ENDPOINT);
    socket.emit("setup", user);
    socket.on('connected', () => setSocketConnected(true));
}, []);

useEffect( () => {
    fetchMessages();

    setSelectedChatRoomCompare = selectedChatRoom;
}, [selectedChatRoom]);

useEffect( () => {
    socket.on('message recieved', (newMessage) => {
        if (!selectedChatRoom || selectedChatRoomCompare._id !== newMessage.chatroom._id){
            setMessages( [...messages, newMessage] );
        }
    })
});

return (
    <>
        {selectedChatRoom ? (
            <>
                <Text
                    fontSize={{ base: "28px", md: "30px" }}
                    pb={3}
                    px={2}
                    w="100%"
                    fontFamily="Ariel"
                    d="flex"
                    justifyContent={{ base: 'space-between' }}
                    alignItems='center'
                >
                    <IconButton
                        d={{ base: 'flex', md: 'none' }}
                        icon={<ArrowBackIcon />}
                        onClick={() => setSelectedChatRoom("")}
                    />
                    {messages && !selectedChatRoom}

                    </IconButton>

                </Text>
            </>
        )}
    </>
)