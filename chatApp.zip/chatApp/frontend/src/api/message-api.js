import instance from './index';

export const createMessage = {
    new: async(message) => {
        await instance.post('/message/create', { message })
    }
}