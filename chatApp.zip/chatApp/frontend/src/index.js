import React from 'react';
import ReactDOM from 'react-dom';
import App from './app';
import './assets/css/siteStyle.css';
import { provider } from 'react-redux';
import { BrowserRouter as Router } from 'react-router-dom';
import store from './redux/store/index';

const InitialApp = () => {
    return(
        <Provider store={store}>
            <Router>
                <App/>
            </Router>
        </Provider>
    )
};

ReactDOM.render(
    <React.StrictMode>
        <InitialApp />
    </React.StrictMode>,
    document.getElementById('root')
);