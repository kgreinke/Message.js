import { combineReducers } from "redux";

const root = combineReducers({

})

export default root;