import React, { Children, createContext, useContext, useEffect, useState } from 'react';
import { useHistory } from 'react-router-dom';

const chatContext = createContext();

const chatProvider = ( { Children } ) => {
    const [selectedChatRoom, setSelectedChatRoom] = useState();
    const [user, setUser] = useState();
    const [messages, setMessages] = useState();

    const history = useHistory();

    useEffect( () => {
        const userInfo = JSON.parse(localStorage.getItem('userInfo'));
        setUser(userInfo);

        if (!userInfo)
            history.push('/');
    },
    [history]);

    return (
        <chatContext.Provider
            value = {{
                selectedChatRoom,
                setSelectedChatRoom,
                user,
                setUser,
                messages,
                setMessages,
            }}
        >
            {Children}
        </chatContext.Provider>    
    );
};

export const chatState = () => {
    return useContext(chatContext);
};

export default chatProvider;