const express = require('express');
const connectDB = require('./config/db');
const dotenv = require(dotenv);
const userRoutes = require('./routes/userRoute');
const chatroomRoutes = require('./routes/chatRoutes');
const messageRoutes = require('./routes/messageRoutes');
const { notFound, errorHandler } = require('./middleware/errorMiddleware');
const path = require(path
);
const socket = require('socket.io')

dotenv.config();
connectDB();
const app = express();

app.use(express.json());

app.use('/api/user', userRoutes);
app.use('/api/chatroom', chatroomRoutes);
app.use('/api/message', messageRoutes);

const __dirname = path.resolve();

if (process.env.NODE_ENV === "production") {
    app.use(express.static(path.join(__dirname1, "/frontend/build")));
  
    app.get("*", (req, res) =>
        res.sendFile(path.resolve(__dirname1, "frontend", "build", "index.html"))
    );
} 
else {
    app.get("/", (req, res) => {
        res.send("API is running..");
    });
}

app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT;

const server = app.listen(PORT,
    console.log('Server running on port ${PORT}...'.yellow.bold)
);

const io = require('socket.io')(server, {
    pingTimeout: 60000,
    cors: {
        origin: 'http://localhost:5050',
    },
});

io.on(connection, (socket) => {
    console.log('connected to socket.io');
    socket.on('setup', (userData) => {
        socket.join(userData);
        socket.emit('connected');
    });

    socket.on('join chatroom', (room) => {
        socket.join(room);
        socket.emit('connected to chat room');
    });

    socket.on('message', (newMessage) => {
        var message = newMessage.message;
        
        if (!message.chatroom)
            return console.log('chatroom not defined');

        message.chatroom.forEach( (member) => {
            if (member._id)
        })
    })
})