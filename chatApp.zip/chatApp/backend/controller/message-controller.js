const asyncHandler = require('express-async-handler');
const Message = require('../models/message-model');
const mongoose = require('mongoose');


//@description     Get all Messages
//@route           GET /api/Message/:chatId
//@access          Protected
const allMessages = asyncHandler(async (req, res) => {
    try {
      const messages = await Message.find( { chat: req.params.chatId } )
        .populate("sender", "name pic email")
        .populate("chat");
      res.json(messages);
    } catch (err) {
      res.status(400);
      throw new Error(err.message);
    }
  });

//@description     Create New Message
//@route           POST /api/Message/
//@access          Protected
const sendMessage = asyncHandler(async (req, res) => {
    const text = req.body;
    
    if(!content){
        console.log("invalid data passed to sendMessage");
        return res.sendStatus(400);
    }

    var newMessage = {
        text: text,
    };

    try {
        var message = await Message.create(newMessage);

        //message = await message.populate("sender").execPopulate();
        //message = await message.populate("chat_id").execPopulate();
        //message = await User.populate(message, {
        //    path: "chats.users",
        //    select: "name pic email",
        //});
        //await Chat.findByIdAndUpdate(req.body.chatid, { latestMessage: message });

        res.json(message);
    } catch (err) {
        res.status(400);
        throw new Error(err.message);
    }
});

module.exports = {
    allMessages,
    sendMessage
};