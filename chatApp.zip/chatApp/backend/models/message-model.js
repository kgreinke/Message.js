'use strict'

const mongoose = require('mongoose');

const MessageSchema = mongoose.Schema({
    message: {
        type: String,
        required: true
    },
    sentDate: {
        type: Date,
        default: Date.now()
    }
},{
    timestamps: true
})

module.exports = mongoose.model('Message', MessageSchema);